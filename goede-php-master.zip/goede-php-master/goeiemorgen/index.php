<!DOCTYPE html>
<html lang="en">
<head>
  <link rel="stylesheet" href="style.css">
<meta charset="utf-8">
<?php
$time = date("H");
if($time < "06") {
  echo "<h1>";
  print "Good Night";
  echo "</h1>";
  $background = 'night';
} elseif($time < "12") {
  echo "<h1>";
  print "Good morning";
  echo "</h1>";
  $background = 'morning';
} elseif($time < "18") {
  echo "<h1>";
  print "Good afternoon";
  echo "</h1>";
  $background = 'afternoon';
} elseif($time < "00") {
  echo "<h1>";
  print "Good Evening";
  echo "</h1>";
  $background = 'evening';
}
?>
</head>
<body id="<?php print $background ?>" onload="startTime()">
    <div id="clock"></div>
    <script src="php.js" type="text/javascript" ></script>
  </body>
</html>
